from .modelnet40_cls import ModelNet40
